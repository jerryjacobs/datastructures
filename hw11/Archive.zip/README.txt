EXTRA CREDIT HOMEWORK: DEBUGGING

NAME: Jerald Jacobs

ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  6

GOAL:
A bright young coder named Lee
Wished to loop while i was 3
But when writing the =
He forgot its sequel
And thus looped infinitely


COLLABORATORS AND OTHER RESOURCES:
http://www.cplusplus.com/reference/cmath/modf/


EXTRA CREDIT:
All the bugs I found and caused the program to either not completely finish the program or they caused the decryption to fail. All are documented in the write up.

MISC COMMENTS:
Significantly changed the pythagoras function (all explained in write up). It effectively does a similar thing as the original code without using a pointer to a double.

When I run the program on my computer, it successfully decrypts the file, but it terminates on the server.