HOMEWORK 2: TENNIS CLASSES


NAME: Jerald Jacobs


COLLABORATORS AND OTHER RESOURCES:
www.stackoverflow.com
www.cplusplus.com
Kareem El-Faramawi

ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT: 8



DESCRIPTION OF 3RD STATISTIC:
The 3rd statistic counts the number of flawless sets that a player has one. For example: 6-0 or 3-0 are flawless sets, but 6-1 or 3-1 is not. As long as they had 0 losses that set, it counts a flawless set. It sorts the players by percentage of flawless sets (flawless sets / total sets) and then alphabetically (last, then first).



RESULTS FROM 3RD STATISTIC:
Input: mens_2014.txt
Output of 3rd stat:

FLAWLESS SET STATISTICS
Player                  FlawSets   percentage
Blaz Kavcic                    2        0.250
Stanislas Wawrinka             4        0.154
Thomaz Bellucci                1        0.143
Guillermo Garcia-Lopez         1        0.143
Stephane Robert                2        0.143
Novak Djokovic                 2        0.118
Adrian Mannarino               1        0.111
Martin Klizan                  1        0.100
Damir Dzumhur                  1        0.091
Rafael Nadal                   2        0.087
Teymuraz Gabashvili            1        0.083
Donald Young                   1        0.083
Fabio Fognini                  1        0.077
Kei Nishikori                  1        0.071
David Ferrer                   1        0.056

It was interesting to see that the top players had a higher rate of flawless sets and that the rankings sort of corresponded with the two other statistics. It’s weird seeing Blaz Kavcic only playing 8 sets but getting 2 flawless sets (25%). Probably an outlier.

